ALTER TABLE #__associations ALTER COLUMN id INT;
